Adding a language or a theme? Make sure to edit the `list.json` file as well, otherwise, it will not work!

Please reference any issues related to your pull request.

If your change is visual (mainly themes) it would be extra awesome if you could include a screenshot.
