---
name: Feature request
about: Please use GitHub Discussions https://github.com/Miodec/monkeytype/discussions
title: ''
labels: ''
assignees: ''

---

Please use GitHub Discussions:
https://github.com/Miodec/monkeytype/discussions
